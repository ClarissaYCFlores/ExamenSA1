import socket


def server_program():
    # obtener el hostname
    host = socket.gethostname()
    port = 5000  # iniaciar el puerto 1024

    server_socket = socket.socket()  # obtener la instancia

    server_socket.bind((host, port))  # vincular host address y el port juntos

    # configure cuantos clientes puede escuchar simultaneamente
    server_socket.listen(2)
    conn, address = server_socket.accept()  # acceptamos una nueva conexion
    print("Connection from: " + str(address))


    while True:
        # receive data stream. no aceptara paquetes de datos mayores a 1024 bytes
        data = conn.recv(1024).decode()
        if not data:
            # si la data no es recibida break
            break
        print("from connected user: " + str(data))
        data = input(' -> ')
        conn.send(data.encode())  # envia el dato del client

    conn.close()  # close la conexion


if __name__ == '__main__':
    server_program()