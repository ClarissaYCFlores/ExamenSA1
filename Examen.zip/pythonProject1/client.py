import socket
import os


def client_program():
    host = socket.gethostname()  # ambos corren en la misma pc
    port = 5000  # socket server numero de purto

    client_socket = socket.socket()  # instanciamos
    client_socket.connect((host, port))  # conectamos al server

    # Defino la varible '' como un diccionario. No es necesario declarar que tipo de dato es
    # base de datos estatica
    clientes = {
        "0606199700088": 500,
        "0606199700086": 350,
        "0606199700084": 300,
        "0606199700081": 400,
        "0606199700089": 400
    }


    def menu():
        """
        Función que limpia la pantalla y muestra nuevamente el menu
        """

        os.system('clear')  # NOTA para windows tienes que cambiar clear por cls

        print("Menu de opciones")

        print("\t1 - Lista de afiliados")
        print("\t2 - Consultar saldo")
        print("\t3 - Pagar Factura")
        print("\t4 - Revertir pago")
        print("\t5 - salir")


    while True:

        # Mostramos el menu

        menu()

        # solicituamos una opción al usuario

        opcionMenu = input("inserta un numero valor >> ")

        if opcionMenu == "1":
            print("*********Listado de afiliados*************")
            for k, v in clientes.items():
                print("clave %s -- Saldo %d" % (k, v))
            print("")

        elif opcionMenu == "2":
            print("*********Consultando factura*************")
            clave = input("Ingrese la clave del cliente a consultar: ")

            elem = clientes.get(clave)
            print("El saldo de la cuenta %s es de L%s" % (clave, elem))
            print("")

        elif opcionMenu == "3":
            print("*********Pagando factura*************")

            clave = input("Ingrese la clave del cliente: ")
            elem = clientes.get(clave)
            copia = elem
            print("Total a pagar L%s" % elem)

            pago = int(input("Ingrese el valor del pago: "))
            total = (elem - pago)

            clientes[clave] = int(total)
            print("Saldo Actual L%s" % total)

            print("")


        elif opcionMenu == "4":
            print("***************Revertir pago************")

            transaccion = int(input("Ingrese el numero de transaccion "))
            elem = clientes.get(transaccion)
            elem = copia
            clientes[transaccion] = int(elem)

            print("Saldo Actual L%s" % copia)

            input("Has pulsado la opción 4...\npulsa una tecla para continuar")
            print("")


        elif opcionMenu == "5":
            break

        else:

            print("")

            input("No has pulsado ninguna opción correcta...\npulsa una tecla para continuar")


    message = input(" -> ")  # tomamos la entrada

    while message.lower().strip() != 'bye':
        client_socket.send(message.encode())  # enviamos el mensaje
        data = client_socket.recv(1024).decode()  # receive la respuesta

        print('Received from server: ' + data)  # mostramos en la terminal

        message = input(" -> ")  # tomamos otra entrada

    client_socket.close()  # cerramos la coneccion


if __name__ == '__main__':
    client_program()